
export const movies = {
    fetchNetflixOriginals: [
        {
            id: 4,
            title: "Money Heist",
            name: "Money Heist",
            poster_path: "https://image.tmdb.org/t/p/original/reEMJA1uzscCbkpeRJeTT2bjqUp.jpg",
            backdrop_path: "https://image.tmdb.org/t/p/original/gKkl37BQuKTanygYQG1pyYgLVgf.jpg",
            overview: "To carry out the biggest heist in history, a mysterious man called The Professor recruits a band of eight robbers who have a single characteristic: none of them has anything to lose.",
            vote_average: 8.3,
        },
    ]
};
